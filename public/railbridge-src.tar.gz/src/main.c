#include "railbridge.h"
#include "internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>
#include <signal.h>

#ifdef _WIN32
#include <windows.h>
static void rb_sleep_ms(int ms) { Sleep(ms); }
#else
#include <pthread.h>
#include <unistd.h>
static void rb_sleep_ms(int ms) { usleep(ms * 1000); }
#endif

static volatile sig_atomic_t g_run = 1;
static void on_sig(int s) {
    (void)s;
    g_run = 0;
}

typedef struct {
    atomic_uint seq;
    rb_pad_t pad;
    uint64_t last_ns;
    uint32_t frames;
    atomic_int present;
} rb_slot_t;

static rb_slot_t g_slots[RB_MAX_PADS];
static rb_config_t g_cfg;
static rb_s1_machine_t g_s1[RB_MAX_HIDG];
static atomic_int g_n_pads;
static atomic_int g_s2_state;

static void slot_write(int slot, const rb_pad_t *p) {
    if (slot < 0 || slot >= RB_MAX_PADS) return;
    rb_slot_t *s = &g_slots[slot];
    unsigned seq = atomic_load_explicit(&s->seq, memory_order_relaxed);
    atomic_store_explicit(&s->seq, seq + 1, memory_order_release);
    s->pad = *p;
    s->pad.slot = (uint8_t)slot;
    s->last_ns = rb_now_ns();
    s->frames++;
    atomic_store_explicit(&s->present, p->valid ? 1 : 0, memory_order_release);
    atomic_store_explicit(&s->seq, seq + 2, memory_order_release);
}

static int slot_read(int slot, rb_pad_t *p, uint64_t *age_ns) {
    if (slot < 0 || slot >= RB_MAX_PADS) return 0;
    rb_slot_t *s = &g_slots[slot];
    for (int i = 0; i < 8; i++) {
        unsigned s1 = atomic_load_explicit(&s->seq, memory_order_acquire);
        if (s1 & 1) continue;
        *p = s->pad;
        uint64_t t = s->last_ns;
        unsigned s2 = atomic_load_explicit(&s->seq, memory_order_acquire);
        if (s1 == s2) {
            *age_ns = t ? rb_now_ns() - t : 0;
            return p->valid;
        }
    }
    return 0;
}

static int count_present(void) {
    int n = 0;
    for (int i = 0; i < RB_MAX_PADS; i++) {
        if (atomic_load(&g_slots[i].present)) n++;
    }
    return n;
}

static void print_usage(void) {
    puts(
        "Railbridge — any wired pad on a Switch 1 console\n"
        "\n"
        "Usage: railbridge [mode] [options]\n"
        "\n"
        "Modes\n"
        "  --auto              Host + gadget on this machine (Pi 4/5)\n"
        "  --host              Wake & read controllers (Switch 2/1, Xbox, DualShock/DualSense)\n"
        "  --gadget            Enumerate toward Switch 1\n"
        "  --sim [N]           Synthetic pads (default 4)\n"
        "  --list              Print supported USB devices and exit\n"
        "\n"
        "Output (Pi USB-C → Switch)\n"
        "  --out auto          1 pad → Pro Controller; 2+ → Pro hub (default)\n"
        "  --out pro           Single Pro Controller (057e:2009)\n"
        "  --out hub           Up to 4 Pro Controller HID functions on one cable\n"
        "  --out gc-adapter    Official GameCube Adapter (057e:0337, 4 ports)\n"
        "\n"
        "Links\n"
        "  --relay HOST:PORT   Extra gadget appliance (repeatable). Pads split evenly.\n"
        "  --listen [IP:]PORT  This gadget appliance listens for --relay\n"
        "  --links N           Number of output links to plan for (default 1)\n"
        "\n"
        "Options\n"
        "  --no-invert-y       Do not invert Switch 2 stick Y\n"
        "\n"
        "Raspberry Pi 4/5 (one box):\n"
        "  Pads --USB→ Pi USB-A (hub OK)     host, up to 8\n"
        "  Pi USB-C --USB-C to USB-A→ dock   one cable, hub or GC adapter\n"
        "  sudo ./railbridge --auto --out hub\n"
        "  sudo ./railbridge --auto --out gc-adapter\n"
        "\n"
        "Windows + Pi gadget(s):\n"
        "  Windows: railbridge --host --relay 192.168.1.50:7433\n"
        "  Pi:      sudo ./railbridge --gadget --listen 0.0.0.0:7433 --out gc-adapter\n"
    );
}

typedef struct {
    char host[128];
    int port;
} rb_relay_ep_t;

typedef struct {
    int auto_mode, host, gadget, sim, list;
    int invert_y;
    int sim_n;
    rb_out_mode_t out_mode;
    int links;
    rb_relay_ep_t relays[RB_MAX_LINKS];
    int nrelays;
    char listen_host[64];
    int listen_port;
} rb_opts_t;

static int parse_hostport(const char *s, char *host, int hostcap, int *port) {
    const char *colon = strrchr(s, ':');
    if (!colon) return -1;
    size_t n = (size_t)(colon - s);
    if (n >= (size_t)hostcap) n = hostcap - 1;
    memcpy(host, s, n);
    host[n] = 0;
    *port = atoi(colon + 1);
    return *port > 0 ? 0 : -1;
}

static int parse_args(int argc, char **argv, rb_opts_t *o) {
    memset(o, 0, sizeof(*o));
    o->invert_y = 1;
    o->auto_mode = 1;
    o->out_mode = RB_OUT_AUTO;
    o->links = 1;
    o->sim_n = 4;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            print_usage();
            exit(0);
        } else if (!strcmp(argv[i], "--auto")) {
            o->auto_mode = 1;
            o->host = o->gadget = 1;
        } else if (!strcmp(argv[i], "--host")) {
            o->host = 1;
            o->auto_mode = 0;
        } else if (!strcmp(argv[i], "--gadget")) {
            o->gadget = 1;
            o->auto_mode = 0;
        } else if (!strcmp(argv[i], "--sim")) {
            o->sim = 1;
            o->auto_mode = 0;
            if (i + 1 < argc && argv[i + 1][0] != '-') {
                o->sim_n = atoi(argv[++i]);
                if (o->sim_n < 1) o->sim_n = 1;
                if (o->sim_n > RB_MAX_PADS) o->sim_n = RB_MAX_PADS;
            }
        } else if (!strcmp(argv[i], "--list")) {
            o->list = 1;
        } else if (!strcmp(argv[i], "--no-invert-y")) {
            o->invert_y = 0;
        } else if (!strcmp(argv[i], "--out") && i + 1 < argc) {
            const char *m = argv[++i];
            if (!strcmp(m, "pro")) o->out_mode = RB_OUT_PRO;
            else if (!strcmp(m, "hub")) o->out_mode = RB_OUT_PRO_HUB;
            else if (!strcmp(m, "gc") || !strcmp(m, "gc-adapter") || !strcmp(m, "adapter"))
                o->out_mode = RB_OUT_GC_ADAPTER;
            else o->out_mode = RB_OUT_AUTO;
        } else if (!strcmp(argv[i], "--links") && i + 1 < argc) {
            o->links = atoi(argv[++i]);
            if (o->links < 1) o->links = 1;
            if (o->links > RB_MAX_LINKS) o->links = RB_MAX_LINKS;
        } else if (!strcmp(argv[i], "--relay") && i + 1 < argc) {
            if (o->nrelays >= RB_MAX_LINKS) return -1;
            if (parse_hostport(argv[++i], o->relays[o->nrelays].host,
                               sizeof(o->relays[0].host), &o->relays[o->nrelays].port) != 0)
                return -1;
            o->nrelays++;
            o->host = 1;
        } else if (!strcmp(argv[i], "--listen") && i + 1 < argc) {
            if (parse_hostport(argv[++i], o->listen_host, sizeof(o->listen_host), &o->listen_port) != 0) {
                o->listen_port = atoi(argv[i]);
                snprintf(o->listen_host, sizeof(o->listen_host), "0.0.0.0");
            }
            o->gadget = 1;
        } else {
            fprintf(stderr, "Unknown arg %s\n", argv[i]);
            return -1;
        }
    }
    if (o->auto_mode) {
        o->host = 1;
        o->gadget = 1;
    }
    if (o->nrelays + (o->gadget ? 1 : 0) > o->links) o->links = o->nrelays + (o->gadget ? 1 : 0);
    if (o->links < 1) o->links = 1;
    return 0;
}

static void mac_for_port(const rb_config_t *base, int port, rb_config_t *out) {
    *out = *base;
    out->mac[5] = (uint8_t)(base->mac[5] + port);
    out->player_led = (uint8_t)(1u << (port & 7));
}

static void collect_pads(int *slots, int nslots, rb_pad_t *pads, int nout) {
    memset(pads, 0, sizeof(rb_pad_t) * (size_t)nout);
    for (int i = 0; i < nout; i++) rb_pad_neutral(&pads[i]);
    for (int i = 0; i < nslots && i < nout; i++) {
        uint64_t age = 0;
        rb_pad_t p;
        if (slot_read(slots[i], &p, &age)) pads[i] = p;
        else {
            rb_pad_neutral(&pads[i]);
            pads[i].valid = false;
        }
    }
}

static int gadget_loop_pro(int *hidg, int nhid, rb_sock_t relay) {
    rb_config_t cfgs[RB_MAX_HIDG];
    for (int i = 0; i < nhid; i++) {
        mac_for_port(&g_cfg, i, &cfgs[i]);
        rb_s1_machine_init(&g_s1[i], &cfgs[i]);
        uint8_t hello[64];
        rb_s1_unsolicited_conn(&cfgs[i], hello);
        if (hidg[i] >= 0) rb_gadget_write(hidg[i], hello, 64);
    }
    uint8_t timer = 0;
    while (g_run) {
        rb_assign_t as[RB_MAX_PADS];
        int np = count_present();
        int nass = rb_plan_assigns(np > 0 ? np : nhid, 1, RB_OUT_PRO_HUB, as, RB_MAX_PADS);
        for (int i = 0; i < nhid; i++) {
            if (hidg[i] < 0) continue;
            uint8_t in[64];
            int n = rb_gadget_read(hidg[i], in, 64);
            if (n > 0) {
                uint8_t reply[64];
                int rn = rb_s1_handle_output(&g_s1[i], &cfgs[i], in, (size_t)n, reply, 64);
                if (rn > 0) rb_gadget_write(hidg[i], reply, 64);
                if (relay > 0) rb_net_send(relay, RB_NET_S1_OUT, in, 64);
            }
            if (g_s1[i].state == RB_S1_STREAMING || g_s1[i].usb_only || g_s1[i].report_mode == 0x30) {
                rb_pad_t pad;
                uint64_t age = 0;
                int slot = (i < nass) ? as[i].slot : i;
                if (!slot_read(slot, &pad, &age)) rb_pad_neutral(&pad);
                uint8_t out[64];
                rb_s1_encode_input(&pad, &cfgs[i], timer, out);
                rb_gadget_write(hidg[i], out, 64);
            }
        }
        timer++;
        rb_sleep_ms(1);
    }
    return 0;
}

static int gadget_loop_gc(int hidg, rb_sock_t relay) {
    int started = 1; /* stream immediately; also honor 0x13 */
    uint8_t rumble[5];
    (void)rumble;
    while (g_run) {
        uint8_t in[64];
        int n = rb_gadget_read(hidg, in, 64);
        if (n > 0) {
            if (in[0] == 0x13 || (n == 1 && in[0] == 0x13)) started = 1;
            if (relay > 0) rb_net_send(relay, RB_NET_S1_OUT, in, (uint8_t)(n > 64 ? 64 : n));
        }
        if (started) {
            rb_pad_t pads[RB_GC_PORTS];
            int slots[RB_GC_PORTS] = {0, 1, 2, 3};
            collect_pads(slots, 4, pads, 4);
            uint8_t rpt[RB_GC_REPORT_LEN];
            rb_gc_encode_adapter(pads, rpt);
            rb_gadget_write(hidg, rpt, RB_GC_REPORT_LEN);
        }
        rb_sleep_ms(1);
    }
    return 0;
}

static int gadget_loop(int *hidg, int nhid, rb_out_mode_t mode, rb_sock_t relay) {
    if (mode == RB_OUT_GC_ADAPTER) return gadget_loop_gc(hidg[0], relay);
    return gadget_loop_pro(hidg, nhid, relay);
}

#ifndef RB_NO_USB
static int next_free_slot(int *used, int nused) {
    for (int s = 0; s < RB_MAX_PADS; s++) {
        int busy = 0;
        for (int i = 0; i < nused; i++)
            if (used[i] == s) {
                busy = 1;
                break;
            }
        if (!busy) return s;
    }
    return -1;
}

static int host_loop(libusb_context *ctx) {
    rb_host_t hosts[RB_MAX_PADS];
    memset(hosts, 0, sizeof(hosts));
    int nh = 0;
    int used_slots[RB_MAX_PADS];
    memset(used_slots, -1, sizeof(used_slots));
    int warned = 0;
    uint64_t last_scan = 0;

    while (g_run) {
        uint64_t now = rb_now_ns();
        if (now - last_scan > 400000000ull || nh == 0) {
            last_scan = now;
            rb_host_t fresh[RB_MAX_PADS];
            int nf = rb_host_open_all(ctx, fresh, RB_MAX_PADS - nh, hosts, nh);
            for (int i = 0; i < nf && nh < RB_MAX_PADS; i++) {
                int slots_needed = fresh[i].gc_ports;
                int base = next_free_slot(used_slots, nh + slots_needed);
                if (base < 0) {
                    rb_host_close(&fresh[i]);
                    continue;
                }
                if (rb_host_wakeup(&fresh[i]) != 0) {
                    fprintf(stderr, "Wake failed for %s\n", rb_kind_name(fresh[i].kind));
                    rb_host_close(&fresh[i]);
                    continue;
                }
                fresh[i].slot = base;
                hosts[nh] = fresh[i];
                used_slots[nh] = base;
                for (int extra = 1; extra < slots_needed && nh + extra < RB_MAX_PADS; extra++)
                    used_slots[nh + extra] = base + extra;
                fprintf(stderr, "Opened %s (%04x:%04x) → slot %d%s\n",
                        rb_kind_name(fresh[i].kind), fresh[i].vid, fresh[i].pid, base,
                        slots_needed > 1 ? " (4 GC ports)" : "");
                nh++;
                if (slots_needed > 1) {
                    /* occupy extra slot indices without extra handles */
                    for (int extra = 1; extra < slots_needed && nh < RB_MAX_PADS; extra++) {
                        /* sentinel: no handle, slot reserved */
                    }
                }
                warned = 0;
                atomic_store(&g_s2_state, RB_S2_STREAMING);
            }
            if (nh == 0 && !warned) {
                fprintf(stderr, "Waiting for pads (Switch 2/1, Xbox, DualShock/DualSense, GC adapter)…\n");
                warned = 1;
            }
        }

        if (nh == 0) {
            rb_sleep_ms(200);
            continue;
        }

        for (int i = 0; i < nh; i++) {
            if (!hosts[i].h) continue;
            uint8_t buf[64];
            int n = rb_host_read_report(&hosts[i], buf, 4);
            if (n < 0) {
                fprintf(stderr, "Disconnected %s slot %d\n", rb_kind_name(hosts[i].kind), hosts[i].slot);
                int ports = hosts[i].gc_ports > 0 ? hosts[i].gc_ports : 1;
                for (int p = 0; p < ports; p++) {
                    rb_pad_t empty;
                    rb_pad_neutral(&empty);
                    slot_write(hosts[i].slot + p, &empty);
                    atomic_store(&g_slots[hosts[i].slot + p].present, 0);
                }
                rb_host_close(&hosts[i]);
                for (int j = i; j < nh - 1; j++) {
                    hosts[j] = hosts[j + 1];
                    used_slots[j] = used_slots[j + 1];
                }
                nh--;
                i--;
                continue;
            }
            if (n == 0) continue;
            if (hosts[i].kind == RB_KIND_GC_ADAPTER) {
                rb_pad_t ports[RB_GC_PORTS];
                int got = rb_gc_parse_adapter(buf, (size_t)n, ports);
                (void)got;
                for (int p = 0; p < RB_GC_PORTS; p++) {
                    rb_pad_t outp;
                    if (ports[p].valid) {
                        rb_translate(&ports[p], &g_cfg, &outp);
                        slot_write(hosts[i].slot + p, &outp);
                    } else {
                        rb_pad_neutral(&outp);
                        slot_write(hosts[i].slot + p, &outp);
                        atomic_store(&g_slots[hosts[i].slot + p].present, 0);
                    }
                }
                continue;
            }
            rb_pad_t raw, outp;
            if (!rb_parse_report(buf, (size_t)n, hosts[i].kind, &raw)) continue;
            raw.kind = hosts[i].kind;
            raw.vid = hosts[i].vid;
            raw.pid = hosts[i].pid;
            uint64_t t0 = rb_now_ns();
            rb_translate(&raw, &g_cfg, &outp);
            uint64_t dt = rb_now_ns() - t0;
            if (dt > 10000000ull) {
                fprintf(stderr, "translate %llu ns exceeds 10 ms budget\n", (unsigned long long)dt);
            }
            slot_write(hosts[i].slot, &outp);
        }
        atomic_store(&g_n_pads, count_present());
    }
    for (int i = 0; i < nh; i++) rb_host_close(&hosts[i]);
    return 0;
}
#endif

static const rb_controller_kind_t k_sim_kinds[] = {
    RB_KIND_S2_PRO, RB_KIND_XBOXSERIES, RB_KIND_DUALSENSE, RB_KIND_S1_PRO,
    RB_KIND_S2_GC, RB_KIND_DS4, RB_KIND_XBOX360, RB_KIND_S1_JC_L
};

static int sim_loop(int n) {
    fprintf(stderr, "SIM: %d mixed pads at 250 Hz\n", n);
    atomic_store(&g_s2_state, RB_S2_STREAMING);
    uint32_t t = 0;
    while (g_run) {
        for (int i = 0; i < n; i++) {
            rb_pad_t p;
            rb_pad_neutral(&p);
            p.kind = k_sim_kinds[i % 8];
            p.valid = true;
            p.lx = (uint16_t)(0x800 + (int)(300 * ((t / 40 + i * 3) % 20 < 10 ? 1 : -1)));
            if ((t / 80 + i) % 8 == 0) p.buttons[0] = 0x08;
            rb_pad_t outp;
            rb_translate(&p, &g_cfg, &outp);
            slot_write(i, &outp);
        }
        t++;
        rb_sleep_ms(4);
    }
    return 0;
}

#ifndef _WIN32
static void *host_thread(void *arg) {
#ifndef RB_NO_USB
    host_loop((libusb_context *)arg);
#else
    (void)arg;
    fprintf(stderr, "USB host not built.\n");
#endif
    return NULL;
}

typedef struct {
    int hidg[RB_MAX_HIDG];
    int nhid;
    rb_out_mode_t mode;
    rb_sock_t relay;
} gadget_args_t;

static void *gadget_thread(void *arg) {
    gadget_args_t *a = arg;
    gadget_loop(a->hidg, a->nhid, a->mode, a->relay);
    return NULL;
}
#endif

int main(int argc, char **argv) {
    rb_opts_t opt;
    if (parse_args(argc, argv, &opt) != 0) {
        print_usage();
        return 2;
    }
    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);
    rb_config_default(&g_cfg);
    g_cfg.invert_y = opt.invert_y != 0;
    g_cfg.out_mode = opt.out_mode;
    g_cfg.links = opt.links;
    atomic_init(&g_s2_state, RB_S2_IDLE);
    atomic_init(&g_n_pads, 0);
    for (int i = 0; i < RB_MAX_PADS; i++) {
        atomic_init(&g_slots[i].seq, 0);
        atomic_init(&g_slots[i].present, 0);
        rb_pad_neutral(&g_slots[i].pad);
    }

#ifndef RB_NO_USB
    libusb_context *ctx = NULL;
    if (opt.list || opt.host) {
        if (libusb_init(&ctx) != 0) {
            fprintf(stderr, "libusb_init failed\n");
            return 1;
        }
    }
    if (opt.list) {
        int n = rb_host_list(ctx);
        libusb_exit(ctx);
        return n >= 0 ? 0 : 1;
    }
#else
    void *ctx = NULL;
    if (opt.list) {
        fprintf(stderr, "Built without libusb.\n");
        return 1;
    }
    (void)ctx;
#endif

    int hidg[RB_MAX_HIDG];
    for (int i = 0; i < RB_MAX_HIDG; i++) hidg[i] = -1;
    int nhid = 0;
    rb_sock_t relay = (rb_sock_t)0;

    if (opt.gadget && opt.listen_port) {
        rb_sock_t ls = rb_net_listen(opt.listen_host[0] ? opt.listen_host : NULL, opt.listen_port);
        if (ls == (rb_sock_t)-1) {
            fprintf(stderr, "listen failed\n");
            return 1;
        }
        fprintf(stderr, "Waiting for host relay…\n");
        relay = rb_net_accept(ls);
    }

    rb_out_mode_t outm = rb_out_resolve(opt.out_mode, opt.sim ? opt.sim_n : 4);
    int fn = rb_out_capacity(outm);
    if (outm == RB_OUT_PRO) fn = 1;

    if (opt.gadget && !opt.listen_port) {
        if (rb_gadget_bind(outm, fn) != 0) {
            fprintf(stderr, "Continuing without local gadget.\n");
        } else {
            nhid = rb_gadget_count();
            if (nhid < 1) nhid = 1;
            for (int i = 0; i < nhid; i++) hidg[i] = rb_gadget_open_index(i);
        }
    }

    if (opt.nrelays) {
        relay = rb_net_connect(opt.relays[0].host, opt.relays[0].port);
        for (int i = 1; i < opt.nrelays; i++) {
            rb_sock_t extra = rb_net_connect(opt.relays[i].host, opt.relays[i].port);
            (void)extra;
            fprintf(stderr, "Additional link %d → %s:%d (even split)\n",
                    i + 1, opt.relays[i].host, opt.relays[i].port);
        }
    }

    fprintf(stderr, "Railbridge ready. out=%s links=%d invert-Y=%s\n",
            rb_out_mode_name(outm), opt.links, g_cfg.invert_y ? "on" : "off");

    if (opt.sim) {
#ifndef _WIN32
        pthread_t tg;
        gadget_args_t ga;
        memset(&ga, 0, sizeof(ga));
        memcpy(ga.hidg, hidg, sizeof(hidg));
        ga.nhid = nhid > 0 ? nhid : 1;
        ga.mode = outm;
        ga.relay = relay;
        if (opt.gadget) pthread_create(&tg, NULL, gadget_thread, &ga);
        sim_loop(opt.sim_n);
        g_run = 0;
        if (opt.gadget) pthread_join(tg, NULL);
#else
        sim_loop(opt.sim_n);
#endif
    } else {
#ifndef _WIN32
        pthread_t th, tg;
        gadget_args_t ga;
        memset(&ga, 0, sizeof(ga));
        memcpy(ga.hidg, hidg, sizeof(hidg));
        ga.nhid = nhid > 0 ? nhid : 1;
        ga.mode = outm;
        ga.relay = relay;
        if (opt.host) pthread_create(&th, NULL, host_thread, ctx);
        if (opt.gadget) pthread_create(&tg, NULL, gadget_thread, &ga);
        while (g_run) rb_sleep_ms(200);
        if (opt.host) pthread_join(th, NULL);
        if (opt.gadget) pthread_join(tg, NULL);
#else
        if (opt.host) {
#ifndef RB_NO_USB
            host_loop(ctx);
#endif
        }
#endif
    }

    for (int i = 0; i < RB_MAX_HIDG; i++) {
        if (hidg[i] >= 0) {
#ifndef _WIN32
            close(hidg[i]);
#endif
        }
    }
    rb_gadget_unbind();
#ifndef RB_NO_USB
    if (ctx) libusb_exit(ctx);
#endif
    return 0;
}

#include "internal.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#ifndef _WIN32
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#endif

/* Nintendo Pro Controller HID report descriptor (64-byte vendor reports). */
static const uint8_t k_hid_desc[] = {
    0x05, 0x01, 0x09, 0x05, 0xA1, 0x01, 0x06, 0x01, 0xFF,
    0x85, 0x21, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x81, 0x02,
    0x85, 0x30, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x81, 0x02,
    0x85, 0x31, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x81, 0x02,
    0x85, 0x32, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x81, 0x02,
    0x85, 0x33, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x81, 0x02,
    0x85, 0x3F, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x81, 0x02,
    0x85, 0x81, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x81, 0x02,
    0x85, 0x01, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x91, 0x02,
    0x85, 0x10, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x91, 0x02,
    0x85, 0x11, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x91, 0x02,
    0x85, 0x12, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x91, 0x02,
    0x85, 0x80, 0x09, 0x01, 0x75, 0x08, 0x95, 0x3F, 0x91, 0x02,
    0xC0
};

/* Official Wii U / Switch GameCube Adapter: report 0x21 (37 bytes in) / 0x11 (5 bytes out). */
static const uint8_t k_gc_desc[] = {
    0x05, 0x01, 0x09, 0x05, 0xA1, 0x01,
    0xA1, 0x00, 0x85, 0x11, 0x19, 0x00, 0x2A, 0xFF, 0x00,
    0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x05, 0x91, 0x00, 0xC0,
    0xA1, 0x00, 0x85, 0x21, 0x15, 0x00, 0x25, 0xFF, 0x75, 0x08, 0x95, 0x25, 0x81, 0x00, 0xC0,
    0xC0
};

static int g_gadget_count = 0;
static int g_gadget_rlen = 64;

#if defined(__linux__)

static int write_file(const char *path, const void *data, size_t n) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    size_t w = fwrite(data, 1, n, f);
    fclose(f);
    return w == n ? 0 : -1;
}

static int write_str(const char *path, const char *s) {
    return write_file(path, s, strlen(s));
}

static int ensure_dir(const char *path) {
    if (mkdir(path, 0755) == 0 || errno == EEXIST) return 0;
    return -1;
}

static int pick_udc(char *out, size_t cap) {
    DIR *d = opendir("/sys/class/udc");
    if (!d) return -1;
    struct dirent *e;
    int rc = -1;
    while ((e = readdir(d))) {
        if (e->d_name[0] == '.') continue;
        snprintf(out, cap, "%.*s", (int)cap - 1, e->d_name);
        rc = 0;
        break;
    }
    closedir(d);
    return rc;
}

static int add_hid_fn(int index, const uint8_t *desc, size_t desclen, const char *rlen) {
    char fn[128], path[192], link[192];
    snprintf(fn, sizeof(fn), "/sys/kernel/config/usb_gadget/railbridge/functions/hid.usb%d", index);
    if (ensure_dir(fn) != 0) return -1;
    snprintf(path, sizeof(path), "%s/protocol", fn);
    write_str(path, "0");
    snprintf(path, sizeof(path), "%s/subclass", fn);
    write_str(path, "0");
    snprintf(path, sizeof(path), "%s/report_length", fn);
    write_str(path, rlen);
    snprintf(path, sizeof(path), "%s/report_desc", fn);
    write_file(path, desc, desclen);
    snprintf(link, sizeof(link), "/sys/kernel/config/usb_gadget/railbridge/configs/c.1/hid.usb%d", index);
    symlink(fn, link);
    return 0;
}

int rb_gadget_bind(rb_out_mode_t mode, int functions) {
    const char *root = "/sys/kernel/config/usb_gadget/railbridge";
    if (ensure_dir("/sys/kernel/config/usb_gadget") != 0) {
        fprintf(stderr, "configfs gadget not available. On a Pi: enable dwc2 (dtoverlay=dwc2) and libcomposite.\n");
        return -1;
    }
    write_str("/sys/kernel/config/usb_gadget/railbridge/UDC", "");
    ensure_dir(root);

    int gc = (mode == RB_OUT_GC_ADAPTER);
    if (functions < 1) functions = 1;
    if (gc) functions = 1;
    if (functions > RB_MAX_HIDG) functions = RB_MAX_HIDG;

    write_str("/sys/kernel/config/usb_gadget/railbridge/idVendor", "0x057e");
    write_str("/sys/kernel/config/usb_gadget/railbridge/idProduct", gc ? "0x0337" : "0x2009");
    write_str("/sys/kernel/config/usb_gadget/railbridge/bcdDevice", "0x0200");
    write_str("/sys/kernel/config/usb_gadget/railbridge/bcdUSB", "0x0200");
    write_str("/sys/kernel/config/usb_gadget/railbridge/bDeviceClass", "0x00");
    write_str("/sys/kernel/config/usb_gadget/railbridge/bDeviceSubClass", "0x00");
    write_str("/sys/kernel/config/usb_gadget/railbridge/bDeviceProtocol", "0x00");
    ensure_dir("/sys/kernel/config/usb_gadget/railbridge/strings/0x409");
    write_str("/sys/kernel/config/usb_gadget/railbridge/strings/0x409/manufacturer", "Nintendo Co., Ltd.");
    write_str("/sys/kernel/config/usb_gadget/railbridge/strings/0x409/product",
              gc ? "WUP-028" : "Pro Controller");
    write_str("/sys/kernel/config/usb_gadget/railbridge/strings/0x409/serialnumber", "000000000001");
    ensure_dir("/sys/kernel/config/usb_gadget/railbridge/configs/c.1");
    ensure_dir("/sys/kernel/config/usb_gadget/railbridge/configs/c.1/strings/0x409");
    write_str("/sys/kernel/config/usb_gadget/railbridge/configs/c.1/strings/0x409/configuration",
              gc ? "GameCube Adapter" : "Pro Controller");
    write_str("/sys/kernel/config/usb_gadget/railbridge/configs/c.1/MaxPower", "500");
    write_str("/sys/kernel/config/usb_gadget/railbridge/configs/c.1/bmAttributes", "0xc0");

    for (int i = 0; i < functions; i++) {
        if (gc) {
            add_hid_fn(i, k_gc_desc, sizeof(k_gc_desc), "37");
        } else {
            add_hid_fn(i, k_hid_desc, sizeof(k_hid_desc), "64");
        }
    }

    char udc[128];
    if (pick_udc(udc, sizeof(udc)) != 0) {
        fprintf(stderr, "No USB device controller. Pi 4/5 USB-C needs dtoverlay=dwc2.\n");
        return -1;
    }
    write_str("/sys/kernel/config/usb_gadget/railbridge/UDC", "");
    if (write_str("/sys/kernel/config/usb_gadget/railbridge/UDC", udc) != 0) {
        fprintf(stderr, "Failed to bind UDC %s\n", udc);
        return -1;
    }
    g_gadget_count = functions;
    g_gadget_rlen = gc ? 37 : 64;
    if (gc) {
        fprintf(stderr, "Gadget bound on UDC %s as 057e:0337 GameCube Adapter (4 ports)\n", udc);
    } else if (functions > 1) {
        fprintf(stderr, "Gadget bound on UDC %s as 057e:2009 Pro hub (%d HID functions)\n", udc, functions);
    } else {
        fprintf(stderr, "Gadget bound on UDC %s as 057e:2009 Pro Controller\n", udc);
    }
    return 0;
}

int rb_gadget_open_index(int i) {
    char path[64];
    snprintf(path, sizeof(path), "/dev/hidg%d", i);
    int fd = open(path, O_RDWR | O_NONBLOCK);
    if (fd < 0) {
        perror(path);
        return -1;
    }
    return fd;
}

int rb_gadget_count(void) { return g_gadget_count; }
int rb_gadget_report_len(void) { return g_gadget_rlen; }

int rb_gadget_write(int fd, const uint8_t *rpt, size_t n) {
    ssize_t w = write(fd, rpt, n);
    return w == (ssize_t)n ? 0 : -1;
}

int rb_gadget_read(int fd, uint8_t *rpt, size_t n) {
    ssize_t r = read(fd, rpt, n);
    if (r < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return 0;
        return -1;
    }
    return (int)r;
}

void rb_gadget_unbind(void) {
    write_str("/sys/kernel/config/usb_gadget/railbridge/UDC", "");
    g_gadget_count = 0;
}

#else

int rb_gadget_bind(rb_out_mode_t mode, int functions) {
    (void)mode;
    (void)functions;
    fprintf(stderr,
            "USB gadget (device) mode is a Linux UDC feature.\n"
            "On Windows, run this machine as --host --relay <pi-ip>:7433\n"
            "and run railbridge --gadget --listen 0.0.0.0:7433 on a Raspberry Pi\n"
            "plugged into the Switch 1 dock.\n");
    return -1;
}

int rb_gadget_open_index(int i) {
    (void)i;
    return -1;
}
int rb_gadget_count(void) { return 0; }
int rb_gadget_report_len(void) { return 64; }
int rb_gadget_write(int fd, const uint8_t *rpt, size_t n) {
    (void)fd;
    (void)rpt;
    (void)n;
    return -1;
}
int rb_gadget_read(int fd, uint8_t *rpt, size_t n) {
    (void)fd;
    (void)rpt;
    (void)n;
    return -1;
}
void rb_gadget_unbind(void) {}

#endif
